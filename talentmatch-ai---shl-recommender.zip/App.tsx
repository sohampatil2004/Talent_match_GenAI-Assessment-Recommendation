import React, { useState } from 'react';
import { AppStep, AssessmentCriteria, RecommendationResponse } from './types';
import { getRecommendations } from './services/geminiService';
import AssessmentForm from './components/AssessmentForm';
import ResultsView from './components/ResultsView';
import { BrainIcon, SparklesIcon, RefreshCwIcon, ArrowLeftIcon } from './components/Icons';

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>(AppStep.LANDING);
  const [criteria, setCriteria] = useState<AssessmentCriteria | null>(null);
  const [results, setResults] = useState<RecommendationResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStart = () => setStep(AppStep.FORM);

  const handleFormSubmit = async (data: AssessmentCriteria) => {
    setCriteria(data);
    setLoading(true);
    setError(null);
    setStep(AppStep.ANALYZING);

    try {
      // Simulate network/processing time for better UX pacing
      const minLoadTime = new Promise(resolve => setTimeout(resolve, 2500));
      const apiCall = getRecommendations(data);
      
      const [response] = await Promise.all([apiCall, minLoadTime]);
      
      setResults(response);
      setStep(AppStep.RESULTS);
    } catch (err) {
      setError("Unable to generate recommendation at this time. Please try again.");
      setStep(AppStep.FORM);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setStep(AppStep.FORM);
    setResults(null);
    setCriteria(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900 selection:bg-shl-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => setStep(AppStep.LANDING)}>
            <div className="bg-gray-900 p-2 rounded-lg text-white transition-transform group-hover:scale-95">
                <BrainIcon className="w-5 h-5" />
            </div>
            <div>
                <h1 className="text-lg font-bold text-gray-900 leading-none">Talent Advisor</h1>
                <span className="text-xs text-shl-600 font-medium">Powered by SHL Labs</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
             {/* Pipeline Status Indicator */}
             <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-gray-50 rounded-full border border-gray-200 text-xs text-gray-500">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                <span>Pipeline: Connected (v2.4)</span>
             </div>

             {step !== AppStep.LANDING && (
                <button 
                    onClick={() => setStep(AppStep.LANDING)}
                    className="text-sm font-medium text-gray-500 hover:text-gray-900 transition-colors px-4 py-2 hover:bg-gray-100 rounded-md"
                >
                    Exit
                </button>
             )}
          </div>
        </div>
      </header>

      <main className="relative pt-12 px-4 sm:px-6 lg:px-8 min-h-[calc(100vh-80px)]">
        
        {/* Landing View */}
        {step === AppStep.LANDING && (
          <div className="max-w-4xl mx-auto text-center pt-16 pb-20 animate-fade-in-up">
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-gray-900 mb-8 leading-tight">
              Science-backed <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-shl-600 to-shl-400">hiring decisions.</span>
            </h1>
            <p className="text-xl text-gray-500 max-w-2xl mx-auto mb-12 leading-relaxed font-light">
              Designing the perfect assessment process requires expertise. <br/>
              Our advisor matches your unique role requirements with proven SHL assessment tools using our intelligent retrieval pipeline.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-5">
              <button
                onClick={handleStart}
                className="group px-10 py-4 bg-gray-900 hover:bg-black text-white text-lg font-medium rounded-xl shadow-xl hover:shadow-2xl transition-all flex items-center gap-3"
              >
                Start Consultation
                <ArrowLeftIcon className="w-5 h-5 rotate-180 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            <div className="mt-24 border-t border-gray-200 pt-12 flex flex-col items-center opacity-70">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-6">Pipeline Data Sources</p>
                <div className="flex justify-center gap-12 grayscale mix-blend-multiply">
                    <div className="text-sm font-bold text-gray-300">SHL Catalogue</div>
                    <div className="text-sm font-bold text-gray-300">Occupational Research</div>
                    <div className="text-sm font-bold text-gray-300">Competency Frameworks</div>
                </div>
            </div>
          </div>
        )}

        {/* Form View */}
        {step === AppStep.FORM && (
          <div className="animate-fade-in">
             {error && (
                <div className="max-w-2xl mx-auto mb-8 p-4 bg-red-50 border border-red-100 text-red-800 text-sm rounded-lg text-center">
                    {error}
                </div>
             )}
            <AssessmentForm onSubmit={handleFormSubmit} isLoading={loading} />
          </div>
        )}

        {/* Analyzing State */}
        {step === AppStep.ANALYZING && (
            <div className="fixed inset-0 flex flex-col items-center justify-center bg-white/80 backdrop-blur-sm z-50">
                <div className="flex flex-col items-center">
                    <div className="w-16 h-16 border-4 border-gray-100 border-t-shl-600 rounded-full animate-spin mb-6"></div>
                    <h3 className="text-2xl font-bold text-gray-900">Running Retrieval Pipeline</h3>
                    <div className="flex flex-col gap-2 mt-4 text-center text-gray-500 text-sm">
                        <span className="animate-pulse delay-75">Embedding job requirements...</span>
                        <span className="animate-pulse delay-150">Querying vector index...</span>
                        <span className="animate-pulse delay-300">Synthesizing recommendation...</span>
                    </div>
                </div>
            </div>
        )}

        {/* Results View */}
        {step === AppStep.RESULTS && results && (
          <ResultsView data={results} onReset={handleReset} />
        )}
      </main>
    </div>
  );
};

export default App;