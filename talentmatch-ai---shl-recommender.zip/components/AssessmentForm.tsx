import React, { useState } from 'react';
import { AssessmentCriteria } from '../types';
import { ChevronRightIcon } from './Icons';

interface Props {
  onSubmit: (criteria: AssessmentCriteria) => void;
  isLoading: boolean;
}

const AssessmentForm: React.FC<Props> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<AssessmentCriteria>({
    jobRole: '',
    industry: '',
    seniorityLevel: 'professional',
    keySkills: '',
    hiringGoal: 'specialist',
  });

  const handleChange = (field: keyof AssessmentCriteria, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.jobRole || !formData.keySkills) return;
    onSubmit(formData);
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
      <div className="bg-gradient-to-r from-shl-800 to-shl-700 p-8">
        <h2 className="text-2xl font-bold text-white tracking-tight">Project Scoping</h2>
        <p className="text-shl-100 mt-2 text-sm leading-relaxed opacity-90">
          Share details about the position. We will cross-reference your needs with our product catalogue to design the optimal screening process.
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-3">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Role Title</label>
            <input
              type="text"
              required
              placeholder="e.g. Senior Solution Architect"
              className="w-full px-4 py-3 bg-gray-50 rounded-lg border-b-2 border-transparent focus:border-shl-500 focus:bg-white transition-colors outline-none font-medium text-gray-800"
              value={formData.jobRole}
              onChange={(e) => handleChange('jobRole', e.target.value)}
            />
          </div>

          <div className="space-y-3">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Industry Sector</label>
            <input
              type="text"
              required
              placeholder="e.g. Financial Services"
              className="w-full px-4 py-3 bg-gray-50 rounded-lg border-b-2 border-transparent focus:border-shl-500 focus:bg-white transition-colors outline-none font-medium text-gray-800"
              value={formData.industry}
              onChange={(e) => handleChange('industry', e.target.value)}
            />
          </div>
        </div>

        <div className="space-y-3">
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Critical Competencies</label>
          <textarea
            required
            placeholder="Describe the skills and behaviors essential for success in this role..."
            className="w-full px-4 py-3 bg-gray-50 rounded-lg border-b-2 border-transparent focus:border-shl-500 focus:bg-white transition-colors outline-none font-medium text-gray-800 h-28 resize-none"
            value={formData.keySkills}
            onChange={(e) => handleChange('keySkills', e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-3">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Candidate Level</label>
            <div className="relative">
              <select
                className="w-full px-4 py-3 bg-gray-50 rounded-lg border-none focus:ring-2 focus:ring-shl-100 outline-none font-medium text-gray-800 appearance-none cursor-pointer"
                value={formData.seniorityLevel}
                onChange={(e) => handleChange('seniorityLevel', e.target.value as any)}
              >
                <option value="entry">Early Careers / Graduate</option>
                <option value="professional">Experienced Professional</option>
                <option value="management">Management / Leadership</option>
                <option value="executive">Executive C-Suite</option>
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                <svg width="10" height="6" viewBox="0 0 10 6" fill="none"><path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Selection Strategy</label>
            <div className="relative">
              <select
                className="w-full px-4 py-3 bg-gray-50 rounded-lg border-none focus:ring-2 focus:ring-shl-100 outline-none font-medium text-gray-800 appearance-none cursor-pointer"
                value={formData.hiringGoal}
                onChange={(e) => handleChange('hiringGoal', e.target.value as any)}
              >
                <option value="volume">High Volume / Efficiency</option>
                <option value="specialist">Specialist / Technical Depth</option>
                <option value="leadership">Leadership Potential</option>
                <option value="development">Talent Development</option>
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                <svg width="10" height="6" viewBox="0 0 10 6" fill="none"><path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-6">
          <button
            type="submit"
            disabled={isLoading}
            className={`w-full flex items-center justify-center gap-3 bg-gray-900 hover:bg-black text-white font-medium py-4 rounded-xl transition-all shadow-xl hover:shadow-2xl active:scale-[0.99] ${isLoading ? 'opacity-80 cursor-wait' : ''}`}
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span className="tracking-wide">Consulting Knowledge Base...</span>
              </>
            ) : (
              <>
                <span className="tracking-wide">Design Solution</span>
                <ChevronRightIcon className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AssessmentForm;