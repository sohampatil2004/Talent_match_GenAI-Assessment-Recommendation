import React, { useState } from 'react';
import { SHLProduct, RecommendationResponse } from '../types';
import { BrainIcon, ClockIcon, CheckCircleIcon, SparklesIcon, BarChartIcon, RefreshCwIcon } from './Icons';

interface Props {
  data: RecommendationResponse & { evaluation?: { confidenceScore: number, missingInformation: string } };
  onReset: () => void;
}

const ProductCard: React.FC<{ product: SHLProduct; index: number }> = ({ product, index }) => (
  <div 
    className="bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] border border-gray-100 overflow-hidden transition-all duration-300 flex flex-col h-full"
    style={{ animationDelay: `${index * 150}ms` }}
  >
    <div className="p-6 flex-1 flex flex-col">
      <div className="flex justify-between items-start mb-6">
        <div>
          <span className="inline-flex items-center px-2.5 py-1 bg-gray-50 text-gray-600 text-[10px] font-bold uppercase tracking-wider rounded-md mb-3 border border-gray-200">
            {product.category}
          </span>
          <h3 className="text-xl font-bold text-gray-900 leading-tight">
            {product.name}
          </h3>
        </div>
        <div className="flex flex-col items-center">
             <div className="flex items-center justify-center w-10 h-10 rounded-full bg-emerald-50 text-emerald-700 font-bold text-sm border border-emerald-100">
                {product.fitScore}
            </div>
            <span className="text-[10px] text-gray-400 font-medium mt-1">FIT</span>
        </div>
      </div>
      
      <p className="text-gray-600 text-sm mb-6 leading-relaxed border-l-2 border-shl-200 pl-4">
        {product.description}
      </p>

      <div className="mb-6">
        <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Expert Insight</p>
        <p className="text-sm text-gray-700 italic bg-gray-50/50 p-3 rounded-lg border border-dashed border-gray-200">
          "{product.reasoning}"
        </p>
      </div>

      <div className="mt-auto pt-6 border-t border-gray-50">
        <ul className="space-y-3 mb-4">
            {product.keyFeatures.slice(0, 3).map((feature, idx) => (
              <li key={idx} className="flex items-start text-sm text-gray-600 group">
                <CheckCircleIcon className="w-4 h-4 text-shl-500 mr-2 mt-0.5 shrink-0 opacity-60 group-hover:opacity-100 transition-opacity" />
                <span className="group-hover:text-gray-900 transition-colors">{feature}</span>
              </li>
            ))}
        </ul>
        <div className="flex items-center text-xs font-medium text-gray-400 gap-1.5 bg-gray-50 inline-block px-3 py-1.5 rounded-full">
            <ClockIcon className="w-3.5 h-3.5" />
            <span>Est. Candidate Time: {product.timeToComplete}</span>
        </div>
      </div>
    </div>
  </div>
);

const FeedbackWidget = () => {
    const [rated, setRated] = useState(false);
    if (rated) return <div className="text-sm text-green-600 font-medium animate-fade-in">Thank you for your feedback. We use this to improve our RAG models.</div>;
    
    return (
        <div className="flex items-center gap-4 text-sm text-gray-500 bg-gray-50 px-4 py-2 rounded-lg border border-gray-200">
            <span>Was this recommendation helpful?</span>
            <div className="flex gap-2">
                <button onClick={() => setRated(true)} className="hover:text-green-600 hover:bg-green-50 p-1 rounded transition-colors">👍 Yes</button>
                <button onClick={() => setRated(true)} className="hover:text-red-600 hover:bg-red-50 p-1 rounded transition-colors">👎 No</button>
            </div>
        </div>
    );
}

const ResultsView: React.FC<Props> = ({ data, onReset }) => {
  return (
    <div className="max-w-7xl mx-auto pb-20 animate-fade-in">
      {/* Self-Evaluation Metrics Header (Visible for Demo) */}
      {data.evaluation && (
          <div className="mb-8 max-w-3xl mx-auto">
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 text-xs text-blue-800 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className="font-bold">AI Self-Audit:</span>
                    <span>Confidence Score: {data.evaluation.confidenceScore}%</span>
                  </div>
                  {data.evaluation.missingInformation && (
                      <span className="opacity-75 truncate max-w-xs" title={data.evaluation.missingInformation}>Note: {data.evaluation.missingInformation}</span>
                  )}
              </div>
          </div>
      )}

      <div className="mb-12 text-center max-w-3xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 tracking-tight">
            Recommended Strategy
        </h2>
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200 text-left relative overflow-hidden">
             <div className="absolute top-0 left-0 w-1 h-full bg-shl-500"></div>
             <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center gap-3 text-gray-900 font-bold text-lg">
                    <div className="p-2 bg-shl-50 rounded-lg text-shl-600">
                        <BarChartIcon className="w-5 h-5" />
                    </div>
                    <span>Consultant's Summary</span>
                 </div>
                 <FeedbackWidget />
             </div>
             <p className="text-gray-600 leading-relaxed text-lg">
                {data.analysis}
            </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-4">
        {data.products.map((product, index) => (
          <ProductCard key={index} product={product} index={index} />
        ))}
      </div>

      <div className="mt-16 text-center border-t border-gray-200 pt-10">
        <p className="text-gray-500 mb-6">Need to adjust the parameters?</p>
        <button
          onClick={onReset}
          className="inline-flex items-center gap-2 px-8 py-3 bg-white border border-gray-200 text-gray-900 font-medium rounded-lg hover:bg-gray-50 hover:border-gray-300 transition-all"
        >
            <RefreshCwIcon className="w-4 h-4" />
            Refine Criteria
        </button>
      </div>
    </div>
  );
};

export default ResultsView;