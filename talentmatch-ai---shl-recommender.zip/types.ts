export interface AssessmentCriteria {
  jobRole: string;
  industry: string;
  seniorityLevel: 'entry' | 'professional' | 'management' | 'executive';
  keySkills: string; // Comma separated
  hiringGoal: 'volume' | 'specialist' | 'leadership' | 'development';
}

export interface SHLProduct {
  name: string;
  category: string;
  description: string;
  fitScore: number; // 0-100
  reasoning: string;
  keyFeatures: string[];
  timeToComplete: string;
}

export interface RecommendationResponse {
  analysis: string;
  products: SHLProduct[];
}

export enum AppStep {
  LANDING,
  FORM,
  ANALYZING,
  RESULTS
}