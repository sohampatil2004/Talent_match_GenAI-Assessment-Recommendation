import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AssessmentCriteria, RecommendationResponse } from "../types";
import { retrieveContext } from "./ragLayer";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    analysis: {
      type: Type.STRING,
      description: "A professional consultation summary explaining the strategy.",
    },
    products: {
      type: Type.ARRAY,
      description: "Selected products from the retrieved context.",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          category: { type: Type.STRING },
          description: { type: Type.STRING },
          fitScore: { type: Type.INTEGER },
          reasoning: { type: Type.STRING },
          keyFeatures: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          timeToComplete: { type: Type.STRING },
        },
        required: ["name", "category", "description", "fitScore", "reasoning", "keyFeatures", "timeToComplete"],
      },
    },
    evaluation: {
       type: Type.OBJECT,
       description: "Self-evaluation metrics of the recommendation quality.",
       properties: {
         confidenceScore: { type: Type.INTEGER, description: "0-100 confidence in this recommendation." },
         missingInformation: { type: Type.STRING, description: "What data was missing that could have improved the result?" }
       }
    }
  },
  required: ["analysis", "products", "evaluation"],
};

export const getRecommendations = async (criteria: AssessmentCriteria): Promise<RecommendationResponse & { evaluation?: any }> => {
  const model = "gemini-2.5-flash";
  
  // STEP 1: RETRIEVAL (RAG)
  const { chunks, debugInfo } = retrieveContext(criteria);
  console.log("RAG Pipeline Info:", debugInfo);
  console.log("Retrieved Chunks:", chunks.map(c => c.name));

  // STEP 2: GENERATION (Augmented Prompt)
  const contextString = chunks.map(c => `PRODUCT: ${c.name}\nTYPE: ${c.category}\nDETAILS: ${c.content}`).join('\n\n');

  const prompt = `
    Act as a Senior I/O Psychologist. Use the retrieved context below to recommend an assessment strategy.
    
    RETRIEVED KNOWLEDGE BASE (Source of Truth):
    ${contextString}
    
    CLIENT REQUEST:
    - Role: ${criteria.jobRole}
    - Industry: ${criteria.industry}
    - Level: ${criteria.seniorityLevel}
    - Skills: ${criteria.keySkills}
    - Goal: ${criteria.hiringGoal}

    INSTRUCTIONS:
    1. Only recommend products found in the KNOWLEDGE BASE.
    2. Explain WHY each product fits the specific client request.
    3. Perform a self-evaluation: How confident are you in this recommendation based on the provided context?
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.2, // Low temperature for factual grounding
      },
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    throw new Error("Generation failed");
  } catch (error) {
    console.error("RAG Pipeline Error:", error);
    throw error;
  }
};