import { SHL_KNOWLEDGE_BASE, ProductNode } from "../data/shlProductCatalogue";
import { AssessmentCriteria } from "../types";

/**
 * SIMULATED VECTOR RETRIEVAL
 * 
 * In a full backend pipeline, this would involve:
 * 1. Converting the user query (Criteria) into a vector embedding (e.g., text-embedding-004).
 * 2. Querying a Vector DB (Pinecone/Weaviate) for nearest neighbors.
 * 
 * Here, we simulate this using a weighted keyword scoring algorithm to select
 * the most relevant "Chunks" from our structured Knowledge Base.
 */

export interface RetrievedContext {
  chunks: ProductNode[];
  debugInfo: string;
}

export const retrieveContext = (criteria: AssessmentCriteria): RetrievedContext => {
  const queryTokens = [
    ...criteria.jobRole.toLowerCase().split(' '),
    ...criteria.industry.toLowerCase().split(' '),
    ...criteria.keySkills.toLowerCase().split(/[ ,]+/),
    criteria.seniorityLevel.toLowerCase(),
    criteria.hiringGoal.toLowerCase()
  ].filter(t => t.length > 2); // Filter stop words loosely

  // Score each document based on token overlap (TF-IDF simulation)
  const scoredDocs = SHL_KNOWLEDGE_BASE.map(doc => {
    let score = 0;
    const docText = `${doc.name} ${doc.category} ${doc.tags.join(' ')} ${doc.content}`.toLowerCase();
    
    queryTokens.forEach(token => {
      if (docText.includes(token)) {
        // Boost score for exact tag matches
        if (doc.tags.includes(token)) score += 3;
        else score += 1;
      }
    });

    // Strategy-based boosting (Heuristic RAG)
    if (criteria.jobRole.match(/developer|engineer|coder|programmer/i) && doc.category === 'Technical') score += 10;
    if (criteria.seniorityLevel === 'executive' && doc.id === 'opq32') score += 5;
    if (criteria.hiringGoal === 'volume' && (doc.id === 'rjp' || doc.id === 'verify-g-plus')) score += 5;

    return { doc, score };
  });

  // Sort by score and take top K (Top 4 chunks)
  const topK = scoredDocs
    .sort((a, b) => b.score - a.score)
    .filter(item => item.score > 0) // Remove irrelevant
    .slice(0, 4)
    .map(item => item.doc);

  // Fallback if no specific matches found (return generic popular tools)
  const finalChunks = topK.length > 0 
    ? topK 
    : SHL_KNOWLEDGE_BASE.filter(d => ['opq32', 'verify-g-plus'].includes(d.id));

  return {
    chunks: finalChunks,
    debugInfo: `Retrieved ${finalChunks.length} documents based on ${queryTokens.length} query tokens.`
  };
};