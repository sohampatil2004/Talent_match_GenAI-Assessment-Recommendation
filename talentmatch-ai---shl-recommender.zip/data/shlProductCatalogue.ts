export interface ProductNode {
  id: string;
  name: string;
  category: string;
  tags: string[];
  content: string; // The "chunk" text for RAG
}

// This represents the stored data after the "Scrape -> Parse -> Store" pipeline.
// In a real backend, this would be in a Vector Database (e.g., Pinecone/Milvus).
export const SHL_KNOWLEDGE_BASE: ProductNode[] = [
  {
    id: "opq32",
    name: "OPQ32 (Occupational Personality Questionnaire)",
    category: "Personality",
    tags: ["leadership", "culture fit", "behavior", "executive", "management", "development", "soft skills"],
    content: "The OPQ32 is the gold standard for measuring behavioral style and cultural fit. It assesses 32 specific personality dimensions relevant to occupational performance. Best used for: Management selection, Leadership development, and deep-dive behavioral analysis. It helps predict how an individual will fit into a team environment."
  },
  {
    id: "verify-g-plus",
    name: "Verify Interactive (G+)",
    category: "Cognitive",
    tags: ["intelligence", "problem solving", "reasoning", "logic", "numerical", "verbal", "graduate", "analyst"],
    content: "Verify Interactive (G+) is a next-generation cognitive ability suite. It utilizes Item Response Theory (IRT) and interactive, game-based mechanics to measure General Ability (G), Numerical Reasoning, and Inductive/Deductive Logic. Features: Mobile-first design, shorter testing time (approx 24 mins), and randomized item banks to prevent cheating."
  },
  {
    id: "amcat-coding",
    name: "SHL Coding (Automata)",
    category: "Technical",
    tags: ["coding", "programming", "software", "developer", "engineer", "java", "python", "syntax"],
    content: "Automata (often part of Aspiring Minds/AMCAT suite) is a robust coding simulation environment. It evaluates code logic, syntax correctness, and edge-case handling in real-time. Supports 50+ programming languages including Java, Python, C++, and SQL. Best for: Software Engineers, Data Scientists, and Backend Developers."
  },
  {
    id: "smart-interview",
    name: "Smart Interview (On-Demand)",
    category: "Interview",
    tags: ["video", "communication", "screening", "sales", "customer service", "remote"],
    content: "Smart Interview is an asynchronous (on-demand) video interviewing tool. Candidates record video responses to pre-set questions. It leverages AI to analyze speech patterns and content (optional configuration). Best for: High-volume screening to replace phone screens, assessing communication skills in Sales or Customer Support roles."
  },
  {
    id: "scenarios",
    name: "Scenarios (Managerial Judgement)",
    category: "Situational Judgement",
    tags: ["management", "judgment", "decision making", "leadership", "conflict", "supervisor"],
    content: "Scenarios tests Managerial Judgement. It presents candidates with realistic workplace dilemmas and asks them to rank possible actions. It measures practical intelligence and the ability to handle conflict, resource allocation, and team motivation. Best for: Identifying high-potential managers and mid-level leadership."
  },
  {
    id: "rjp",
    name: "Realistic Job Previews (RJP)",
    category: "Engagement",
    tags: ["volume", "retail", "entry level", "attrition", "expectations", "culture"],
    content: "Realistic Job Previews are interactive, multimedia experiences that show candidates the 'good, bad, and ugly' of a job before they apply. It acts as a self-selection tool to reduce early attrition. Best for: High-volume roles like Retail, Call Centers, and Hospitality."
  },
  {
    id: "verify-checking",
    name: "Verify Checking",
    category: "Skills",
    tags: ["admin", "clerical", "detail", "data entry", "accuracy", "speed"],
    content: "Verify Checking measures the ability to quickly and accurately detect errors in data. It is a speed-and-accuracy test. Best for: Administrative assistants, Data Entry clerks, Warehouse operations, and Quality Assurance roles."
  },
  {
    id: "mobilize",
    name: "Mobilize",
    category: "Internal Mobility",
    tags: ["internal", "succession", "high potential", "hipo", "audit"],
    content: "Mobilize is a digital assessment experience designed to uncover hidden talent within an existing workforce. It combines personality and ability data to identify high-potential employees for succession planning or role changes."
  }
];